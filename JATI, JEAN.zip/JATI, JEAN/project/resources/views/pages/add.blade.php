@extends('layout.master')
@section('title')
	Add Event
@endsection
@section('content')

	<div class="container">
		<center>
            <div class="card bg-dark mt-5" style="width: 25rem; height: 400px;">
			    <div class="card-body">
		            <div class="col-md-10">
			            <h4 class="text-warning">Add Event</h4>

			            <form action="{{route('events.store')}}" method="post">
				               @csrf
				                 @method('post')
				           
                            <div class="form-group text-white">
					            Event Name: <input type="text" class="form-control" name="event_input" required> 
					            Date: <input type="date" class="form-control" name="date_input"required>
					            Venue: <input type="text" class="form-control" name="venue_input" required>
					            In Charge: <input type="text" class="form-control" name="incharge_input" required>

					            <input type="submit" value="Add" class=" mt-4 btn btn-info">
					            <a class=" mt-4 btn btn-info" href="{{route('events.index')}}">Cancel</a>
				            </div>

			            </form>

		            </div>
	            </div>
            </div>
        </center>
	</div>
@endsection
