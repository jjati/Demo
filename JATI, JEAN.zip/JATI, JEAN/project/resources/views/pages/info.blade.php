@extends('Layout.master')
@section('title')
    Event Information
@endsection

@section('content')

    <div class="container"> 
		<center>
            <div class="card bg-dark mt-5 pt-5" style="width: 25rem; height: 400px;">
			    <div class="card-body">
		            <div class="col-md-10 text-white">
                    <h4 class="text-warning bg-dark">Event Details</h4>

                        <center>
                            <h5 class="mt-5"><b>Name of the Event:<b> {{$events->event_name}} </h5>
                            <h5><b>Schedule:<b> {{$events->schedule}}</h5>
                            <h5><b>Venue:<b> {{$events->venue}} </h5>
                            <h5><b>In-Charge:<b> {{$events->event_incharge}} </h5>
        
                            <button class="button btn-info mt-5 text-warning bg-dark" style="border-radius: 5px;"><a href="{{route('events.index')}}">Back</a></button>
                        </center>

		            </div>
	            </div>
            </div>
        </center>
	</div>

@endsection
