<?php

namespace App\Http\Controllers;
use App\Models\Event;

use Illuminate\Http\Request;

class EventController extends Controller
{
    public function index(){

        $events = Event::all();
        return view("pages.home")->with("events", $events);
    }

    public function create(){
        return view("pages.add");
    }

    public function store(Request $request)
    {
        $event = new Event();
        $event->event_name=$request -> event_input;
        $event->schedule=$request -> date_input;
        $event->venue=$request -> venue_input;
        $event->event_incharge=$request -> incharge_input;

        $event->save();
        return redirect()->route("events.index");
    }
    
    public function show($id){
        $events = Event::find($id);
        return view("pages.info")->with("events", $events);
    }

    public function edit($id)
    {
        $events = Event::find($id);
        return view("pages.edit")->with("events", $events);
    }

    public function update(Request $request, $id)
    {
        $event = Event::find($id);
        $event->event_name=$request -> event_input;
        $event->schedule=$request -> date_input;
        $event->venue=$request -> venue_input;
        $event->event_incharge=$request -> incharge_input;

        $event->save();
        return redirect()->route("events.index");
    }

    
    public function destroy(Request $request, $id)
    {
        $events = Event::find($id);
        $events->delete();
        return redirect()->route("events.index");
    }



}
