
<?php $__env->startSection('title'); ?>
    Event System
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container border border-dark mt-3">

    <h5 class="mt-3 ms-5"><b>Events Management System<b></h5>
    <a href="<?php echo e(route('events.create')); ?>"><span class="btn btn-outline-primary btn-sm mt-5 ms-5">+</span></a>
    
    
        <div class="row">
          <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-md-4 mb-3">
                <div class="card bg-dark mt-5" style="border-radius: 10px;">
                    <div class="card-body bg.info mt-3"> 
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end"> 
                        <form action="<?php echo e(route('events.destroy', $event->id)); ?>" method="post">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>

                            <button class="btn btn-outline-danger btn-sm" onclick="return confirm ('Are u sure u want to delete this event?')" ><i class="fa fa-times mb-5 mt-3" aria-label="Close"></i>X</button>

                            
                        </form> 
                        </div>  
                        <center>
                            <h5 class="text-warning bg-dark"><?php echo e($event->event_name); ?></h5><br>   
                            <button class="btn btn-outline-info mt-3 mb-3" style="border-radius: 5px;"><a href="<?php echo e(route('events.show', $event->id)); ?>">View</a></button>
                            <button class="btn btn-outline-info mt-3 mb-3" style="border-radius: 5px;"><a href="<?php echo e(route('events.edit', $event->id)); ?>">Edit</a></button>
                        </center>
                    </div>
                </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
</div>   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\chong\Laraval App\project\resources\views/pages/home.blade.php ENDPATH**/ ?>