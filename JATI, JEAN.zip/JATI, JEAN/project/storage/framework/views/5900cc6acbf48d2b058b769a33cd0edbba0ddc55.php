
<?php $__env->startSection('title'); ?>
	Edit Event
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container"> 
		<center>
            <div class="card bg-dark mt-5 pt-5" style="width: 20rem;">
			    <div class="card-body">
		            <div class="col-md-10">
			            <h4 class="text-warning">Edit Event</h4>

	                    <form action="<?php echo e(route('events.update', $events->id)); ?>" method="post">
				            <?php echo csrf_field(); ?>
				            <?php echo method_field('put'); ?>
							<center>
				            <div class="form-group">
					            <label class="form-label">Event</label>
					            <input type="text" value="<?php echo e($events -> event_column); ?>" class="form-control mb-3" name="event_input" placeholder="Enter event here" required>
					            <input type="date" value="<?php echo e($events -> schedule); ?>" class="form-control mb-3" name="date_input" placeholder="Date" required>
					            <input type="text" value="<?php echo e($events -> venue); ?>" class="form-control mb-3" name="venue_input" placeholder="Venue" required>
					            <input type="text" value="<?php echo e($events-> in_charge); ?>" class="form-control mb-3" name="incharge_input" placeholder="In Charge" required>

					            <input type="submit" value="Update" class=" mt-2 btn btn-info mb-3 ms-3">
								<a class="mt-2 btn btn-info mb-3" href="<?php echo e(route('events.index')); ?>">Cancel</a>
								
				            </div>
							</center>
			            </form>

				            </div>
			            </form>
		            </div>
	            </div>
            </div>
        </center>
	</div>


	
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\chong\Laraval App\project\resources\views/pages/edit.blade.php ENDPATH**/ ?>